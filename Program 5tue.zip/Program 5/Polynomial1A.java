import java.util.ArrayList; // imports array list to be used in this program my brothers let us begin the fight LETS US MARCH INTO WAR

class Polynomial1A //implements Quantity
{
    ArrayList<Term> poly; // the polynomial BROTHERS
    
    Polynomial1A()
    {
        poly = new ArrayList<Term>();
    }
    
   /*===================================================================================================================================
   |  Method add
   |
   |        Purpose: Mathematically adds the polynomial 'p' to the current Polynomial, returning a new Polynomial object. Neither of
   |                 the existing Polynomial objects are changed. If both Polynomials possess terms with matching exponents, sum each
   |                 pair of matching terms.
   |
   |     Parameters: Polynomial p - the polynomial to be added to the current polynomial object.
   |
   |    Pre-Condition: Polynomial p is passed in but will not be changed and neither will the current object polynomial.
   |   Post-Condition: Polynomial object result contains the addition of two polynomials but none have been altered.
   |
   |        Returns:  result - the polynomial with the results in it
   *=================================================================================================================================*/ 
  private Polynomial add(Polynomial p)
  {   
    Polynomial result = new Polynomial();
    result.poly = this.poly;
    
    for(int i = 0; i < p.poly.length; i++)
      result.addTerm(p.poly[i].getCoeff(), p.poly[i].getExpo());
    
    return result;
  } // end add
} // end class